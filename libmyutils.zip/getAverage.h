#ifndef GETAVERAGE_H
#define GETAVERAGE_H

double getAverage(int* array, int length);

#endif
