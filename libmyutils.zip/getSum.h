#ifndef GETSUM_H
#define GETSUM_H

int getSum(int* array, int length);

#endif
